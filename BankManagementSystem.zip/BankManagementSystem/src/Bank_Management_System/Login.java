package Bank_Management_System;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Login extends JFrame implements ActionListener {

    JLabel label1,label2,label3;
    JTextField cardno;
    JPasswordField pin;
    JButton login,Clear,SignUp;


    Login(){

        super("Bank Management System");

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2 = i1.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(350,10,100,100);
        add(image);

        ImageIcon j1 = new ImageIcon(ClassLoader.getSystemResource("icon/card.png"));
        Image j2 = j1.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);
        ImageIcon j3 = new ImageIcon(j2);
        JLabel image1 = new JLabel(j3);
        image1.setBounds(630,350,100,100);
        add(image1);



        label1 = new JLabel("WELCOME TO ATM");
        label1.setForeground(Color.white);
        label1.setFont(new Font("AvantGrade",Font.BOLD,38));
        label1.setBounds(230,125,450,40);
        add(label1);

        label2 = new JLabel("Card No: ");
        label2.setFont(new Font("Ralway",Font.BOLD,28));
        label2.setForeground(Color.white);
        label2.setBounds(150,190,375,30);
        add(label2);

        cardno = new JTextField();
        cardno.setFont(new Font("Ralway",Font.BOLD,14));
        cardno.setBounds(300,190,375,30);
        cardno.isMaximumSizeSet();
        add(cardno);

        label3= new JLabel("PIN: ");
        label3.setFont(new Font("Ralway",Font.BOLD,28));
        label3.setForeground(Color.white);
        label3.setBounds(150,250,375,30);
        add(label3);

        pin=new JPasswordField();
        pin.setFont(new Font("Ralway",Font.BOLD,14));
        pin.setBounds(300,250,375,28);
        add(pin);

        login = new JButton("Log-in");
        login.setFont(new Font("Ralway",Font.BOLD,14));
        login.setForeground(Color.white);
        login.setBackground(Color.black);
        login.setBounds(300,300,100,30);
        login.addActionListener(this);
        add(login);

        Clear = new JButton("Clear");
        Clear.setFont(new Font("Arial",Font.BOLD,14));
        Clear.setForeground(Color.white);
        Clear.setBackground(Color.black);
        Clear.setBounds(430,300,100,30);
        Clear.addActionListener(this);
        add(Clear);

        SignUp=new JButton("Sign-Up");
        SignUp.setFont(new Font("Arial",Font.BOLD,14));
        SignUp.setForeground(Color.white);
        SignUp.setBackground(Color.black);
        SignUp.setBounds(300,350,230,30);
        SignUp.addActionListener(this);
        add(SignUp);


        ImageIcon k1 = new ImageIcon(ClassLoader.getSystemResource("icon/Backbg.png"));
        Image k2=k1.getImage().getScaledInstance(850,480,Image.SCALE_DEFAULT );
        ImageIcon k3 = new ImageIcon(k2);
        JLabel image3 = new JLabel(k3);
        image3.setBounds(0,0,850,480);
        add(image3);


        setLayout(null);
        setSize(850,580);
        setLocation(450,200);
        setUndecorated(true);
        setVisible(true);

    }
    public static void main(String[] args) {
        new Login();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        try {
            if(e.getSource()==login){
                Con c=new Con();
                String cardnumber=cardno.getText();
                String pinnumber=pin.getText();

                try{
                    String query="select * from login where cardnumber= '"+cardnumber+"' and pin = '"+pinnumber+"'";
                   ResultSet resultSet= c.statement.executeQuery(query);
                   if (resultSet.next()){
                       setVisible(false);
                       new Transactions(pinnumber).setVisible(true);
                   }else {
                       JOptionPane.showMessageDialog(null,"Incorrect cardnumber or pin");
                   }

                }catch (Exception e1){
                    System.out.println(e1);
                }



            } else if (e.getSource()==Clear) {
                cardno.setText("");
                pin.setText("");
            } else if (e.getSource()==SignUp) {
                setVisible(false);
                new SignUp().setVisible(true);
            }
        }catch (Exception e1){
                e1.printStackTrace();
        }

    }
}
