package Bank_Management_System;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class signup3 extends JFrame implements ActionListener {

    JRadioButton r1,r2,r3,r4;
    JCheckBox c1,c2,c3,c4,c5,c6,c7;
    JButton submit,cancel;
    String formno;

    signup3(String formno){
        this.formno= formno;

        setLayout(null);
        setTitle("New bank account opening");

        JLabel l1= new JLabel("Page 3:Additional Details");
        l1.setFont(new Font("Raleway",Font.BOLD,20));
        l1.setBounds(280,40,400,40);
        add(l1);

        JLabel type= new JLabel("Account type");
        type.setFont(new Font("Raleway",Font.BOLD,20));
        type.setBounds(100,140,200,30);
        add(type);

        r1=new JRadioButton("Saving account");
        r1.setFont(new Font("Arial",Font.BOLD,20));
        r1.setBackground(Color.white);
        r1. setBounds(100,180,175,20);
        add(r1);

        r2=new JRadioButton("Fixed Deposite account");
        r2.setFont(new Font("Arial",Font.BOLD,20));
        r2.setBackground(Color.white);
        r2. setBounds(350,180,250,20);
        add(r2);

        r3=new JRadioButton("Current account");
        r3.setFont(new Font("Arial",Font.BOLD,20));
        r3.setBackground(Color.white);
        r3. setBounds(100,220,185,20);
        add(r3);

        r4=new JRadioButton("Recurring account");
        r4.setFont(new Font("Arial",Font.BOLD,20));
        r4.setBackground(Color.white);
        r4. setBounds(350,220,200,20);
        add(r4);

        ButtonGroup buttonGroup= new ButtonGroup();
        buttonGroup.add(r1);
        buttonGroup.add(r2);
        buttonGroup.add(r3);
        buttonGroup.add(r4);

        JLabel cardno = new JLabel("Card Number");
        cardno.setFont(new Font("Arial",Font.BOLD,20));
        cardno.setBounds(100,270,200,20);
        add(cardno);


        JLabel number = new JLabel("XXXX-XXXX-XXXX-4148");
        number.setFont(new Font("Arial",Font.BOLD,20));
        number.setBounds(360,270,250,20);
        add(number);

        JLabel cardDetails = new JLabel("Your 16 digits card Details");
        cardDetails.setFont(new Font("Arial",Font.BOLD,10));
        cardDetails.setBounds(100,290,250,10);
        add(cardDetails);

        JLabel Pin = new JLabel("PIN");
        Pin.setFont(new Font("Arial",Font.BOLD,20));
        Pin.setBounds(100,340,250,20);
        add(Pin);

        JLabel pindetails = new JLabel("enter your pin number");
        pindetails.setFont(new Font("Arial",Font.BOLD,10));
        pindetails.setBounds(100,360,250,10);
        add(pindetails);

        JLabel  pinNumber= new JLabel("XXXX");
        pinNumber.setFont(new Font("Arial",Font.BOLD,20));
        pinNumber.setBounds(360,340,100,20);
        add(pinNumber);

        JLabel services = new JLabel("Services Required: ");
        services.setFont(new Font("Arial",Font.BOLD,20));
        services.setBounds(100,410,250,20);
        add(services);

        c1=new JCheckBox("ATM Card");
        c1.setBackground(Color.white);
        c1.setFont(new Font("Arial",Font.BOLD,15));
        c1.setBounds(100,460,150,20);
        add(c1);

        c2=new JCheckBox("Mobile Banking");
        c2.setBackground(Color.white);
        c2.setFont(new Font("Arial",Font.BOLD,15));
        c2.setBounds(350,460,150,20);
        add(c2);
        c3=new JCheckBox("Internet banking");
        c3.setBackground(Color.white);
        c3.setFont(new Font("Arial",Font.BOLD,15));
        c3.setBounds(100,510,150,20);
        add(c3);

        c4=new JCheckBox("Email and SMS Alerts");
        c4.setBackground(Color.white);
        c4.setFont(new Font("Arial",Font.BOLD,15));
        c4.setBounds(350,510,180,20);
        add(c4);


        c5=new JCheckBox("Check Book ");
        c5.setBackground(Color.white);
        c5.setFont(new Font("Arial",Font.BOLD,15));
        c5.setBounds(100,560,150,20);
        add(c5);


        c6=new JCheckBox("E-Statement");
        c6.setBackground(Color.white);
        c6.setFont(new Font("Arial",Font.BOLD,15));
        c6.setBounds(350,560,150,20);
        add(c6);

        c7=new JCheckBox("I hereby Declared that the above details which i have filled/Entered are correct of my best of knowledge.");
        c7.setBackground(Color.white);
        c7.setFont(new Font("Arial",Font.BOLD,12));
        c7.setBounds(100,610,609,20);
        add(c7);


        //CheckboxGroup checkboxGroup=new CheckboxGroup();

        submit=new JButton("Submit");
        submit.setFont(new Font("Arial",Font.BOLD,20));
        submit.setForeground(Color.white);
        submit.setBackground(Color.black);
        submit.setBounds(100,660,110,20);
        submit.addActionListener(this);
        add(submit);

        cancel=new JButton("Cancel");
        cancel.setFont(new Font("Arial",Font.BOLD,20));
        cancel.setForeground(Color.white);
        cancel.setBackground(Color.black);
        cancel.setBounds(350,660,110,20);
        cancel.addActionListener(this);
        add(cancel);


        getContentPane().setBackground(Color.white);
        setSize(850,850);
        setLocation(350,10);
        setVisible(true);

    }


    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource()==submit){

            String accounttype=null;
            if(r1.isSelected()){
                accounttype= "Saving Account";
            } else if (r2.isSelected()) {
                accounttype = "Fixed Deposite Account";
            } else if (r3.isSelected()) {
                accounttype = " Current Account";
            } else if (r4.isSelected()) {
                accounttype = "Recurring Deposite account";
            }
            Random random = new Random();
            String  cardnumber = ""+Math.abs((random.nextLong() % 90000000L) + 50409360000000001l);

            String  pinnumber = ""+Math.abs((random.nextLong() % 9000L) + 1000l);

            String facility = "";
            if(c1.isSelected()){
                facility= facility+ " ATM Card";
            }
            if(c2.isSelected()){
                facility= facility+ " Internet banking";
            }
            if(c3.isSelected()){
                facility= facility+ " Mobile Banking";
            }
            if(c4.isSelected()){
                facility= facility+ " Email and SMS Alerts";
            }
            if(c5.isSelected()){
                facility= facility+ " Check Book";
            }
            if(c6.isSelected()){
                facility= facility+ " E-statement";
            }

            try{

                if (accounttype.equals("")){
                    JOptionPane.showMessageDialog(null,"Account type is Required");
                }else {
                    Con c1= new Con();

                    String query ="insert into signup3 Values('"+formno+"','"+accounttype+"','"+cardnumber+"','"+pinnumber+"','"+facility+"')";
                    String query1 ="insert into login Values('"+formno+"','"+cardnumber+"','"+pinnumber+"')";

                c1.statement.executeUpdate(query);
                c1.statement.executeUpdate(query1);

                JOptionPane.showMessageDialog(null,"Card Number"+ cardnumber +"\n PIN : "+pinnumber);
                }

                setVisible(false);
                new Deposit(pinnumber).setVisible(false);


            }catch (Exception e){
                System.out.println(e);
            }


        } else if (ae.getSource()==cancel) {

            setVisible(false);
            new Login().setVisible(true);

            
        }


    }

    public static void main(String[] args) {

        new signup3("");
    }
}
