package Bank_Management_System;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SignUp2 extends JFrame implements ActionListener {

    JLabel Religion,Category,Income,Education,Qualification,occupation,PAN,Aadhar,Senior,Existing;
    JComboBox religion1,category1,income1,education1,Occupation1;
    JTextField pan,aadhar;
    JRadioButton Yes,No,existingYes,existingNo;
    JButton Next1;
    String formno;


    SignUp2(String formno){
        this.formno= formno;

        setLayout(null);
        setTitle("New APPLICATION FORM Page 2");

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2=i1.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image=new JLabel(i3);
        image.setBounds(25,10,100,100);
        add(image);


        JLabel Additionaldetails  = new JLabel("Page 2 : Additional Details ");
        Additionaldetails.setFont(new Font("arial",Font.BOLD,30));
        Additionaldetails.setBounds(160,20,520,40);
        add(Additionaldetails);

        Religion = new JLabel("Religion: ");
        Religion.setFont(new Font("arial",Font.BOLD,20));
        Religion.setBounds(100,140,170,30);
        add(Religion);

        String religion[]= {"Hindu","Buddhists","Jain",};
        religion1 = new JComboBox(religion);
        religion1.setBounds(310,140,400,30);
        add(religion1);

        Category = new JLabel("Category: ");
        Category.setFont(new Font("Arial",Font.BOLD,20));
        Category.setBounds(100,190,170,30);
        add(Category);

        String category[] = {"GENERAL","OBC","SC","ST","OTHERS"};
        category1 = new JComboBox(category);
        category1.setBounds(310,190,400,30);
        add(category1);

        Income = new JLabel("Income: ");
        Income.setFont(new Font("Arial",Font.BOLD,20));
        Income.setBounds(100,240,170,30);
        add(Income);

        String income[] = {"NULL","<250000","<500000","<1000000"};
        income1 = new JComboBox(income);
        income1.setBounds(310,240,400,30);
        add(income1);

        Education = new JLabel("Educational");
        Education.setFont(new Font("Arial",Font.BOLD,20));
        Education.setBounds(100,290,170,30);
        add(Education);

        Qualification = new JLabel("Qualification:");
        Qualification.setFont(new Font("Arial",Font.BOLD,20));
        Qualification.setBounds(100,310,170,30);
        add(Qualification);

        String education[] = {"Non-Graduate","Graduate","Post-Graduate","Others"};
        education1 = new JComboBox(education);
        education1.setBounds(310,290,400,30);
        add(education1);



        occupation = new JLabel("Occupation: ");
        occupation.setFont(new Font("Arial",Font.BOLD,20));
        occupation.setBounds(100,360,170,30);
        add(occupation);

        String Occupation[] = {"Salaried","Self-Employed","Bussiness","Student","others"};
        Occupation1 = new JComboBox(Occupation);
        Occupation1.setBounds(310,360,400,20);
        add(Occupation1);

        PAN = new JLabel("PAN Number: ");
        PAN.setFont(new Font("Arial",Font.BOLD,20));
        PAN.setBounds(100,410,170,30);
        add(PAN);

        pan = new JTextField();
        pan.setFont(new Font("Arial",Font.BOLD,20));
        pan.setBounds(310,410,400,30);
        add(pan);

        Aadhar = new JLabel("Aadhar Number: ");
        Aadhar.setFont(new Font("Arial",Font.BOLD,20));
        Aadhar.setBounds(100,460,170,30);
        add(Aadhar);

        aadhar = new JTextField();
        aadhar.setFont(new Font("Arial",Font.BOLD,20));
        aadhar.setBounds(310,460,400,30);
        add(aadhar);

        Senior = new JLabel("Senior Citizen: ");
        Senior.setFont(new Font("Arial",Font.BOLD,20));
        Senior.setBounds(100,510,170,30);
        add(Senior);

        Yes = new JRadioButton("Yes");
        Yes.setBounds(310,510,50,30);
        add(Yes);

        No= new JRadioButton("No");
        No.setBounds(450,510,50,30);
        add(No);
        ButtonGroup yes=new ButtonGroup();
        yes.add(Yes);
        yes.add(No);

        Existing = new JLabel("Existing Account: ");
        Existing.setFont(new Font("Arial",Font.BOLD,20));
        Existing.setBounds(100,560,220,30);
        add(Existing);

        existingYes = new JRadioButton("Yes");
        existingYes.setBounds(310,560,50,30);
        add(existingYes);

        existingNo = new JRadioButton("No");
        existingNo.setBounds(450,560,50,30);
        add(existingNo);


        ButtonGroup buttonGroup=new ButtonGroup();
        buttonGroup.add(existingYes);
        buttonGroup.add(existingNo);

        JButton Next1 = new JButton("NEXT");
        Next1.setForeground(Color.WHITE);
        Next1.setBackground(Color.BLACK);
        Next1.setFont(new Font("Arial",Font.BOLD,20));
        Next1.setBounds(600,600,100,30);
        Next1.addActionListener(this);
        add(Next1);


        getContentPane().setBackground(Color.CYAN);
        setSize(850,800);
        setVisible(true);
        setLocation(350,50);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
         String sreligion = (String) religion1.getSelectedItem();
         String scategoty = (String) category1.getSelectedItem();
         String sincome = (String) income1.getSelectedItem();
         String seducation = (String) education1.getSelectedItem();
         String soccupation = (String) Occupation1.getSelectedItem();
         String sseniorcitizen = null;
         if(Yes.isSelected()){
             sseniorcitizen="Yes";
         }else if (No.isSelected()){
             sseniorcitizen="No";
         }
         String sExisting = null;
        if(existingYes.isSelected()){
            sExisting="Yes";
        }else if (existingNo.isSelected()){
            sExisting="No";
        }
        String span= PAN.getText();
        String saadhar= Aadhar.getText();
        try{

            Con con1 = new Con();
            String query = "insert into SignUp2 Values('"+formno+"','"+sreligion+"','"+scategoty+"','"+sincome+"','"+seducation+"','"+soccupation+"','"+span+"','"+saadhar+"','"+sseniorcitizen+"',"+sExisting+"')";
            con1.statement.executeUpdate(query);
            setVisible(false);
           // new SignUp3().setVisible(true);

        }catch (Exception e){
            e.printStackTrace();
        }


    }

    public static void main(String[] args) {
        new SignUp2("");
    }




}
