package Bank_Management_System;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Transactions extends JFrame  implements ActionListener {

    JButton deposit,withdraw,Fastcash,ministatement,Pinchange,Balanceinquiry,exit;
    String pinnumber;


    Transactions( String pinnumber){
        this.pinnumber=pinnumber;

        setLayout(null);
        setTitle("Transaction page for Bank");

        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icon/atm.jpg"));
        Image i2= i1.getImage().getScaledInstance(900,900,Image.SCALE_DEFAULT);
        ImageIcon i3= new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0,900,900);
        add(image);

        JLabel text= new JLabel("Please select your Transaction  ");
        text.setBounds(210,300,700,35);
        text.setFont(new Font("Raleway",Font.BOLD,16));
        text.setForeground(Color.white);
        image.add(text);

        deposit = new JButton("Deposit");
        deposit.setBounds(170,418,100,30);
        deposit.addActionListener(this);
        image.add(deposit);

        withdraw = new JButton("Withdraw");
        withdraw.setBounds(390,418,120,30);
        withdraw.addActionListener(this);
        image.add(withdraw);

        Fastcash = new JButton("Fast Cash");
        Fastcash.setBounds(170,452,100,30);
        Fastcash.addActionListener(this);
        image.add(Fastcash);

        ministatement = new JButton("Mini Statement");
        ministatement.setBounds(390,452,120,30);
        ministatement.addActionListener(this);
        image.add(ministatement);

        Pinchange = new JButton("Pin-Change");
        Pinchange.setBounds(170,485,100,30);
        Pinchange.addActionListener(this);
        image.add(Pinchange);

        Balanceinquiry = new JButton("Balance Inquiry");
        Balanceinquiry.setBounds(390,485,122,30);
        Balanceinquiry.addActionListener(this);
        image.add(Balanceinquiry);

        exit = new JButton("Exit");
        exit.setBounds(390,518,122,30);
        exit.addActionListener(this);
        image.add(exit);


        setSize(900,900);
        setLocation(300,0);
        setUndecorated(true);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Transactions("");
    }

    @Override
    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource()==exit){
            System.exit(0);
        } else if (ae.getSource()==deposit) {
            setVisible(false);
            new Deposit(pinnumber).setVisible(true);
         } else if (ae.getSource()==withdraw) {
            setVisible(false);
            new Withdraw(pinnumber).setVisible(true);

        } else if (ae.getSource()==Fastcash) {
            setVisible(false);
            new FastCash(pinnumber).setVisible(true);

        } else if (ae.getSource()==Pinchange) {
            setVisible(false);
            new PinChange(pinnumber).setVisible(true);

        } else if (ae.getSource()==Balanceinquiry) {
            setVisible(false);
            new BalanceEnquiry(pinnumber).setVisible(true);

        } else if (ae.getSource()==ministatement) {

            new MiniStatement(pinnumber).setVisible(true);
            
        }
    }
}
