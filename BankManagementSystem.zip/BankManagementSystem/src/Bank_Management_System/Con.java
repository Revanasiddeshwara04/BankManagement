package Bank_Management_System;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Con {

    Connection connection;
    Statement statement;
    public Con(){


        try{

            connection = DriverManager.getConnection("jdbc:mysql:///BankSystem","root","Anaveer@1989");
            statement=connection.createStatement();

        }catch (Exception e){
            System.out.println(e);
        }
    }


}
