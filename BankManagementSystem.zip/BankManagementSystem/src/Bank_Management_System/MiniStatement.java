package Bank_Management_System;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class MiniStatement extends JFrame implements ActionListener {
    String pinnumber;

    MiniStatement( String  pinnumber){
        this.pinnumber = pinnumber;

        setTitle("Mini Statement ");

        setLayout(null);

        JLabel mini = new JLabel();

        add(mini);

        JLabel bank = new JLabel("Indian Bank");
        bank.setBounds(150,20,100,20);
        add(bank);


        JLabel card = new JLabel();
        card.setBounds(20,80,300,20);
        add(card);

        JLabel balance = new JLabel();
        balance.setBounds(20,400,300,20);
        add(balance);

        try{
            Con c1=new Con();
            ResultSet rs = c1.statement.executeQuery("select * from login where  pin = '"+pinnumber+"'");
            while (rs.next()){
                card.setText("Card Number: "+ rs.getString("cardnumber").substring(0,4)+ "XXXXXXX" + rs.getString("cardnumber").substring(12));
            }

        }catch (Exception e1){
            e1.printStackTrace();
        }
        try{

            Con c = new Con();
            ResultSet rs = c.statement.executeQuery("select * from bank where pin = '"+pinnumber+"'");
            while (rs.next()){
                mini.setText(mini.getText() + "<html>" + rs.getString("date")+"&nbsp:&nbsp:&nbsp:&nbsp:&nbsp:" + rs.getString("type")+"&nbsp:&nbsp:&nbsp:&nbsp:"+rs.getString("amount")+"<br><br><br><html>");

            }

        }catch (Exception e2){
            e2.printStackTrace();
        }

        try{
            Con c = new Con();

            int bal = 0;
            ResultSet rs1 =c.statement.executeQuery("select * from bank where pin ='"+pinnumber+"'");
            while (rs1.next()){
                if (rs1.getString("type").equals("Deposit")){
                    bal+=Integer.parseInt(rs1.getString("amount"));
                }else{
                    bal-=Integer.parseInt(rs1.getString("amount"));
                }
            }
            balance.setText("Your current Account balance is "+bal);

        }catch (Exception e){
            e.printStackTrace();
        }

        mini.setBounds(20,140,400,200);





        setSize(900,900);
        setLocation(350,0);
        getContentPane().setBackground(Color.white);
        setVisible(true);



    }
    @Override
    public void actionPerformed(ActionEvent e) {

    }

    public static void main(String[] args) {
        new MiniStatement(" ");
    }
}
