package Bank_Management_System;

import com.sun.source.tree.NewArrayTree;
import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class SignUp extends JFrame implements ActionListener {

    JDateChooser dateChooser;
    JLabel gender,marriedStatus,Email,Address,City,State,Pin;

    JTextField textname,PinText,fathertext,EmailText,AddressText,CityText,StateText;
    JRadioButton r1,r2 ,Married,Single,Divorce;
    JButton Next;


    Random ran=new Random();
    long random=(ran.nextLong() % 9000L)+1000l;
    String first=""+Math.abs(random);
    SignUp(){

        super("APPLICATION FORM");

        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2=i1.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image=new JLabel(i3);
        image.setBounds(25,10,100,100);
        add(image);




        JLabel formno=new JLabel("Application form no: "+first);
        formno.setBounds(160,20,600,40);
        formno.setFont(new Font("Ralway",Font.BOLD,40));
        add(formno);

        JLabel personalDetails=new JLabel("Page 1 : PersonalDetails");
        personalDetails.setBounds(290,70,600,30);
        personalDetails.setFont(new Font("Ralway",Font.BOLD,22));
        add(personalDetails);

        JLabel name = new JLabel("Name: ");
        name.setFont(new Font("Ralway",Font.BOLD,20));
        name.setBounds(100,140,220,20);
        add(name);

        textname = new JTextField();
        textname.setFont(new Font("Arial",Font.BOLD,12));
        textname.setBounds(300,140,300,20);
        add(textname);

        JLabel fname= new JLabel("Father-Name:");
        fname.setFont(new Font("Arial",Font.BOLD,20));
        fname.setBounds(100,190,220,20);
        add(fname);

        fathertext = new JTextField();
        fathertext.setFont(new Font("Arial",Font.BOLD,12));
        fathertext.setBounds(300,190,300,20);
        add(fathertext);

        JLabel dob = new JLabel("Date-Of-Birth: ");
        dob.setFont(new Font("Arial",Font.BOLD,20));
        dob.setBounds(100,240,220,20);
        add(dob);



        dateChooser = new JDateChooser();
        dateChooser.setForeground(new Color( 105,105,105));
        dateChooser.setBounds(300,240,300,20);
        add(dateChooser);

        gender=new JLabel("Gender:");
        gender.setFont(new Font("Arial",Font.BOLD,20));
        gender.setBounds(100,290,220,20);
        add(gender);

        r1=new JRadioButton("Male");
        r1.setFont(new Font("Arial",Font.BOLD,20));
        r1.setBounds(300,290,69,20);
        add(r1);

        r2 = new JRadioButton("Female");
        r2.setFont(new Font("Arial",Font.BOLD,20));
        r2.setBounds(450,290,93,20);
        add(r2);

        ButtonGroup groupstatus1 = new ButtonGroup();
        groupstatus1.add(this.r1);
        groupstatus1.add(this.r2);



        marriedStatus=new JLabel("Marital-Status:");
        marriedStatus.setFont(new Font("Arial",Font.BOLD,20));
        marriedStatus.setBounds(100,340,220,20);
        add(marriedStatus);

        Single = new JRadioButton("Single");
        Single.setFont(new Font("Arial",Font.BOLD,20));
        Single.setBounds(300,340,83,20);
        add(Single);

        Married = new JRadioButton("Married");
        Married.setFont(new Font("Arial",Font.BOLD,20));
        Married.setBounds(390,340,100,20);
        add(Married);

        Divorce = new JRadioButton("Divorce");
        Divorce.setFont(new Font("Arial",Font.BOLD,20));
        Divorce.setBounds(500,340,100,20);
        add(Divorce);

        ButtonGroup groupstatus = new ButtonGroup();
        groupstatus.add(this.Single);
        groupstatus.add(this.Married);
        groupstatus.add(this.Divorce);


        Email = new JLabel("Email: ");
        Email.setFont(new Font("Arial",Font.BOLD,20));
        Email.setBounds(100,390,220,20);
        add(Email);

        EmailText = new JTextField();
        EmailText.setFont(new Font("Arial",Font.BOLD,12));
        EmailText.setBounds(300,390,300,20);
        add(EmailText);

        Address = new JLabel("Address: ");
        Address.setFont(new Font("Arial",Font.BOLD,20));
        Address.setBounds(100,440,220,20);
        add(Address);

        AddressText = new JTextField();
        AddressText.setFont(new Font("Arial",Font.BOLD,12));
        AddressText.setBounds(300,440,300,20);
        add(AddressText);

        City = new JLabel("City:");
        City.setFont(new Font("Arial",Font.BOLD,20));
        City.setBounds(100,490,220,20);
        add(City);

        CityText = new JTextField();
        CityText.setFont(new Font("Arial",Font.BOLD,12));
        CityText.setBounds(300,490,300,20);
        add(CityText);

        State = new JLabel("State: ");
        State.setFont(new Font("Arial",Font.BOLD,20));
        State.setBounds(100,540,220,20);
        add(State);

        StateText = new JTextField();
        StateText.setFont(new Font("Arial",Font.BOLD,12));
        StateText.setBounds(300,540,300,20);
        add(StateText);

        Pin = new JLabel("Pincode: ");
        Pin.setFont(new Font("Arial",Font.BOLD,20));
        Pin.setBounds(100,590,220,20);
        add(Pin);

        PinText = new JTextField();
        PinText.setFont(new Font("Arial",Font.BOLD,12));
        PinText.setBounds(300,590,300,20);
        add(PinText);

        Next =new JButton("Next");
        Next.setFont(new Font("Arial",Font.BOLD,20));
        Next.setForeground(Color.white);
        Next.setBackground(Color.black);
        Next.setBounds(550,630,100,20);
        Next.addActionListener(this);
        add(Next);




        getContentPane().setBackground(new Color(222,255,228));
        setLayout(null);
        setSize(850,800);
        setLocation(360,40);
        setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

        String formno =first;
        String name=textname.getText();
        String fname= fathertext.getText();
        String dob = ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
        String gender = null;
        if(r1.isSelected()) {
            gender = "Male";
        }else if
        (r2.isSelected()){
            gender="Female";
        }
        String Email = EmailText.getText();
        String married = null;
        if(Single.isSelected()){
            married="Single";
        }else if (Married.isSelected()){
            married = "married";
        }else if(Divorce.isSelected()){
            married="Divorce";
        }
        String AddressText1=AddressText.getText();
        String CityText1=CityText.getText();
        String StateText1=StateText.getText();
        String PinText1=PinText.getText();

        try{

            if (textname.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Fill All the Fields");
            }else {
                Con con1 = new Con();
                String insert = "insert into SignUp values('"+formno+"','"+name+"','"+fname+"','"+dob+"','"+gender+"','"+Email+"','"+married+"','"+AddressText1+"' ,'"+CityText1+"','"+StateText1+"','"+PinText1+"')";

                con1.statement.executeUpdate(insert);
                setVisible(false);
                new signuptwo(formno).setVisible(true);

            }

        }catch (Exception e1){
            e1.printStackTrace();
        }
    }



    public static void main(String[] args) {
        new SignUp();
    }


}
