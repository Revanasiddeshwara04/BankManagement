package Bank_Management_System;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class signuptwo extends JFrame implements ActionListener {

    JLabel name,fname,gender,marriedStatus,Email,Address,City,State,Pin;

    JTextField aadhar,pan;
    JRadioButton syes,sno,eyes,eno;
    JButton Next;
    String formno;

    JComboBox religion,category,income,education,occupation;
    signuptwo( String formno){
        this.formno=formno;

        setTitle("APPLICATION FORM Page :2");

        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2=i1.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image=new JLabel(i3);
        image.setBounds(25,10,100,100);
        add(image);


        JLabel personalDetails=new JLabel("Page 2 : PersonalDetails");
        personalDetails.setBounds(290,40,600,30);
        personalDetails.setFont(new Font("Ralway",Font.BOLD,22));
        add(personalDetails);

        name = new JLabel("Religion: ");
        name.setFont(new Font("Ralway",Font.BOLD,20));
        name.setBounds(100,140,220,20);
        add(name);

       String valReligion[] = {"Hindu","Buddhists"," Jain","Christianity","Muslim"};
       religion = new JComboBox(valReligion);
       religion.setBounds(300,140,300,20);
       religion.setBackground(Color.white);
       add(religion);

        fname= new JLabel("Category:");
        fname.setFont(new Font("Arial",Font.BOLD,20));
        fname.setBounds(100,190,220,20);
        add(fname);

        String valcategory [] ={"General","OBC","SC","ST"};
        category = new JComboBox(valcategory);
        category.setBounds(300,190,300,20);
        category.setBackground(Color.white);
        add(category);



        JLabel dob = new JLabel("Income: ");
        dob.setFont(new Font("Arial",Font.BOLD,20));
        dob.setBounds(100,240,220,20);
        add(dob);



        String valincome [] ={"NULL","<250000","<500000","1000000"};
        income = new JComboBox(valincome);
        income.setBounds(300,240,300,20);
        income.setBackground(Color.white);
        add(income);

        gender=new JLabel("Educational");
        gender.setFont(new Font("Arial",Font.BOLD,20));
        gender.setBounds(100,290,220,20);
        add(gender);
        Email = new JLabel("Qualification: ");
        Email.setFont(new Font("Arial",Font.BOLD,20));
        Email.setBounds(100,315,220,20);
        add(Email);

        String valeduction [] ={"Non-Graduate","Graduate","Post-Graduate","PHD"};
        education = new JComboBox(valeduction);
        education.setBounds(300,315,300,20);
        add(education);

         JLabel occupation1 = new JLabel("Occupation: ");
        occupation1.setFont(new Font("Arial",Font.BOLD,20));
        occupation1.setBounds(100,390,300,20);
        add(occupation1);

        String valoccupation [] ={"Salaried ","self-employed","business","Retired"};
        occupation = new JComboBox(valoccupation);
        occupation.setBounds(300,390,300,20);
        add(occupation);

        Address = new JLabel("PAN: ");
        Address.setFont(new Font("Arial",Font.BOLD,20));
        Address.setBounds(100,440,220,20);
        add(Address);

        pan = new JTextField();
        pan.setFont(new Font("Arial",Font.BOLD,12));
        pan.setBounds(300,440,300,20);
        add(pan);

        City = new JLabel("Aadhar: ");
        City.setFont(new Font("Arial",Font.BOLD,20));
        City.setBounds(100,490,220,20);
        add(City);

        aadhar = new JTextField();
        aadhar.setFont(new Font("Arial",Font.BOLD,12));
        aadhar.setBounds(300,490,300,20);
        add(aadhar);

        State = new JLabel("Senior Citizen: ");
        State.setFont(new Font("Arial",Font.BOLD,20));
        State.setBounds(100,540,220,20);
        add(State);

        syes = new JRadioButton("Yes");
        syes.setFont(new Font("Arial",Font.BOLD,20));
        syes.setBounds(300,540,70,20);
        add(syes);

        sno = new JRadioButton("No");
        sno.setFont(new Font("Arial",Font.BOLD,20));
        sno.setBounds(400,540,70,20);
        add(sno);

        ButtonGroup maritalgroup = new ButtonGroup();
        maritalgroup.add(syes);
        maritalgroup.add(sno);


        Pin = new JLabel("Existing Account:");
        Pin.setFont(new Font("Arial",Font.BOLD,20));
        Pin.setBounds(100,590,220,20);
        add(Pin);

        eyes = new JRadioButton("Yes");
        eyes.setFont(new Font("Arial",Font.BOLD,20));
        eyes.setBounds(300,590,70,20);
        add(eyes);

         eno = new JRadioButton("No");
        eno.setFont(new Font("Arial",Font.BOLD,20));
        eno.setBounds(400,590,70,20);
        add(eno);

        ButtonGroup maritalgroup1 = new ButtonGroup();
        maritalgroup1.add(eno);
        maritalgroup1.add(eyes);


        Next =new JButton("Next");
        Next.setFont(new Font("Arial",Font.BOLD,20));
        Next.setForeground(Color.white);
        Next.setBackground(Color.black);
        Next.setBounds(550,630,100,20);
        Next.addActionListener(this);
        add(Next);




        getContentPane().setBackground(new Color(222,255,228));
        setLayout(null);
        setSize(850,800);
        setLocation(360,40);
        setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

        String sreligion=(String) religion.getSelectedItem();
        String scategory= (String)category.getSelectedItem();
        String sincome = (String) income.getSelectedItem();
        String seducation =(String) education.getSelectedItem();
        String soccupation= (String) occupation.getSelectedItem();
        String seniorcitizen= null;
        if(syes.isSelected()) {
            seniorcitizen = "Yes";
        }else if
        (sno.isSelected()){
            seniorcitizen="No";
        }
        String existingaccount = null;
        if(eyes.isSelected()){
            existingaccount="Yes";
        }else if (eno.isSelected()){
            existingaccount = "No";}
       String span = pan.getText();
       String saadhar = aadhar.getText();

        try{

                Con con1 = new Con();
                String insert = "insert into signuptwo values('"+formno+"','"+sreligion+"','"+scategory+"','"+sincome+"','"+seducation+"','"+soccupation+"','"+span+"','"+saadhar+"','"+seniorcitizen+"' ,'"+existingaccount+"')";

                con1.statement.executeUpdate(insert);
                setVisible(false);
                new signup3(formno).setVisible(true);

        }catch (Exception e1){
            e1.printStackTrace();
        }
    }



    public static void main(String[] args) {
        new signuptwo(" ");
    }


}
