package Bank_Management_System;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.*;


public class FastCash extends JFrame  implements ActionListener {

    JButton deposit,withdraw,Fastcash,ministatement,Pinchange,Balanceinquiry,Back;
    String pinnumber;


    FastCash( String pinnumber){
        this.pinnumber=pinnumber;

        setLayout(null);
        setTitle("Transaction page for Bank");

        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icon/atm.jpg"));
        Image i2= i1.getImage().getScaledInstance(900,900,Image.SCALE_DEFAULT);
        ImageIcon i3= new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0,900,900);
        add(image);

        JLabel text= new JLabel("SELECT WITHDRAWAL AMOUNT  ");
        text.setBounds(210,300,700,35);
        text.setFont(new Font("System",Font.BOLD,16));
        text.setForeground(Color.white);
        image.add(text);

        deposit = new JButton("Rs 100");
        deposit.setBounds(170,418,100,30);
        deposit.addActionListener(this);
        image.add(deposit);

        withdraw = new JButton("Rs 500");
        withdraw.setBounds(390,418,120,30);
        withdraw.addActionListener(this);
        image.add(withdraw);

        Fastcash = new JButton("Rs 1000");
        Fastcash.setBounds(170,452,100,30);
        Fastcash.addActionListener(this);
        image.add(Fastcash);

        ministatement = new JButton("Rs 2000");
        ministatement.setBounds(390,452,120,30);
        ministatement.addActionListener(this);
        image.add(ministatement);

        Pinchange = new JButton("Rs 5000");
        Pinchange.setBounds(170,485,100,30);
        Pinchange.addActionListener(this);
        image.add(Pinchange);

        Balanceinquiry = new JButton("Rs 10000");
        Balanceinquiry.setBounds(390,485,122,30);
        Balanceinquiry.addActionListener(this);
        image.add(Balanceinquiry);

        Back = new JButton("BACK");
        Back.setBounds(390,518,122,30);
        Back.addActionListener(this);
        image.add(Back);


        setSize(900,900);
        setLocation(300,0);
        setUndecorated(true);
        setVisible(true);
    }

    public static void main(String[] args) {
        new FastCash("");
    }

    @Override
    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource()==Back){
            setVisible(false);
            new Transactions(pinnumber).setVisible(true);

        } else  {
            String amount =( (JButton)ae.getSource()).getText().substring(3);//Rs 500
            Con c=new Con();

            try{

                ResultSet rs = c.statement.executeQuery("select * from bank where pin= '"+pinnumber+"'");
                int balance = 0;
                while (rs.next()){
                    if (rs.getString("type").equals("Deposit")){
                        balance+=Integer.parseInt(rs.getString("amount"));
                    }else{
                        balance-=Integer.parseInt(rs.getString("amount"));
                    }
                }

                if(ae.getSource()!=Back && balance<Integer.parseInt(amount)){
                    JOptionPane.showMessageDialog(null,"Insufficient Balance ");
                    return;
                }

                Date date=new Date();
                String query = "insert into bank values('"+pinnumber+"','"+date+"','Withdraw','"+amount+"')";
                c.statement.executeUpdate(query);
                JOptionPane.showMessageDialog(null,"Rs "+amount+" "+"Debited successfully");
                setVisible(false);
                new Transactions(pinnumber).setVisible(true);

            }catch (Exception e){
                e.printStackTrace();
            }

        }
    }
}
